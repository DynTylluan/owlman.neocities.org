This is the shareware copy of Doom https://owlman.neocities.org/doom.zip

Oh also FreeDoom